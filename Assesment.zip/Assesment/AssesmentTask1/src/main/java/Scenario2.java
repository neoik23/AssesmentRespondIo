import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Scenario2 {
    public static void main(String[] args) {
        // Set the path to the ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");

        // Launch the Chrome browser
        WebDriver driver = new ChromeDriver();

        // Navigate to the /clothing/dresses page
        driver.get("https://iprice.my/clothing/dresses/");

        // Click on Price sorting until the indicator indicates that the list is sorted by price in descending order
        WebElement priceSortingButton = driver.findElement(By.cssSelector(".sort-by .sort-item-price"));
        WebElement priceSortingIndicator = driver.findElement(By.cssSelector(".sort-by .sort-item-price .sort-icon"));
        String sortingIndicatorClass;
        do {
            priceSortingButton.click();
            sortingIndicatorClass = priceSortingIndicator.getAttribute("class");
        } while (!sortingIndicatorClass.contains("icon-sort-down"));

        // Validate that the results are sorted in descending order of Price
        List<WebElement> priceElements = driver.findElements(By.cssSelector(".item .price"));
        List<Double> prices = new ArrayList<>();
        for (WebElement priceElement : priceElements) {
            String priceStr = priceElement.getText().replace("RM", "").replace(",", "").trim();
            double price = Double.parseDouble(priceStr);
            prices.add(price);
        }
        List<Double> expectedPrices = new ArrayList<>(prices);
        Collections.sort(expectedPrices, Collections.reverseOrder());
        if (prices.equals(expectedPrices)) {
            System.out.println("Test Passed: Results are sorted in descending order of Price.");
        } else {
            System.out.println("Test Failed: Results are not sorted in descending order of Price.");
        }

        // Close the browser
        driver.quit();
    }
}
