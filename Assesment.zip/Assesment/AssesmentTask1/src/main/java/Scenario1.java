import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Scenario1 {
    public static void main(String[] args) {
        // Set the path to the ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");

        // Launch the Chrome browser
        WebDriver driver = new ChromeDriver();

        // Navigate to the /computing/laptops page
        driver.get("https://iprice.my/computing/laptops/");

        // Select the brand value to be Dell
        WebElement brandDropdown = driver.findElement(By.cssSelector(".filter-group-brand .filter-dropdown-toggle"));
        brandDropdown.click();
        WebElement dellCheckbox = driver.findElement(By.xpath("//label[contains(text(), 'Dell')]/input"));
        dellCheckbox.click();

        // Wait for the page to load and validate that the results returned from page 1 matches the selected brand
        WebElement resultsTitle = driver.findElement(By.cssSelector(".search-title .keyword"));
        String results = resultsTitle.getText();
        if (results.contains("Dell")) {
            System.out.println("Test Passed: Results returned matches the selected brand.");
        } else {
            System.out.println("Test Failed: Results returned does not match the selected brand.");
        }

        // Close the browser
        driver.quit();
    }
}
