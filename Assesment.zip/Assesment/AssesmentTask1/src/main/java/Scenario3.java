import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;

public class Scenario3 {
    public static void main(String[] args) {
        // Set the path to the ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");

        // Launch the Chrome browser
        WebDriver driver = new ChromeDriver();

        // Navigate to the homepage
        driver.get("https://iprice.my/");

        // Search for "iPhone 14"
        WebElement searchBox = driver.findElement(By.cssSelector(".search-bar input[name='q']"));
        searchBox.sendKeys("iPhone 14");
        searchBox.submit();

        // Validate that the search results returned matches the search criteria
        List<WebElement> searchResults = driver.findElements(By.cssSelector(".item .name"));
        boolean searchResultMatch = searchResults.stream()
                .allMatch(result -> result.getText().toLowerCase().contains("iphone 14"));
        if (searchResultMatch) {
            System.out.println("Test Passed: Search results match the search criteria.");
        } else {
            System.out.println("Test Failed: Search results do not match the search criteria.");
        }

        // Close the browser
        driver.quit();
    }
}
